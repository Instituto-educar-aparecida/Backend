// Rotas do aluno (RF05, RF10, RF16, RF17, RF18, RF19).
import { Router } from 'express';
import * as studentController from '../Controllers/studentController.js';
import { authenticateToken, authorizeRoles } from '../middlewares/auth.middleware.js';
import { validate } from '../utils/validate.js';
import { USER_ROLE } from '../domain/enums/userRole.enum.js';
import { updateProfileSchema, enrollmentSchema, reviewSchema } from '../validators/student.schema.js';

const router = Router();

// Todas as rotas do aluno exigem autenticação de STUDENT.
router.use(authenticateToken, authorizeRoles(USER_ROLE.STUDENT));

// Perfil (RF05).
router.put('/profile', validate(updateProfileSchema), studentController.updateProfile);

// Painel do aluno (RF17).
router.get('/dashboard', studentController.getDashboard);

// Cursos matriculados (RF16).
router.get('/courses', studentController.getMyCourses);
router.get('/courses/:courseId/progress', studentController.getCourseProgress);

// Matrículas (RF10).
router.post('/enrollments', validate(enrollmentSchema), studentController.enroll);
router.delete('/enrollments/:courseId', studentController.cancelEnrollment);

// Avaliações (RF19).
router.post('/reviews', validate(reviewSchema), studentController.reviewCourse);

// Certificados (RF18).
router.get('/certificates', studentController.getCertificates);
router.post('/courses/:courseId/certificate', studentController.issueCertificate);

export default router;
